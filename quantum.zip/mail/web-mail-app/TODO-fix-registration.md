# TODO: Fix Registration Issue

## Steps to Complete
- [x] Manually update .env file with DATABASE_URL (e.g., DATABASE_URL=mongodb://localhost:27017/web-mail-app)
- [x] Ensure MongoDB is running locally (bypassed for demo)
- [x] Start the server using `node src/server.js`
- [ ] Test registration: Open register.html, fill form with valid data (username, Gmail email, 6-10 char alphanumeric password), submit
- [ ] Verify registration success: Check redirect to login.html with success message
- [ ] Test login: Use new credentials to log in and access inbox.html
