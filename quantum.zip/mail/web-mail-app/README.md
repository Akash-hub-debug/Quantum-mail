# Web Mail Application

## Overview
This project is a web-based email application that allows users to register, log in, compose, and send emails. It is built using Node.js and Express, with a simple front-end interface.

## Features
- User registration and login
- Compose and send emails
- View inbox with received emails

## Project Structure
```
web-mail-app
├── src
│   ├── server.js                # Entry point of the application
│   ├── controllers
│   │   ├── authController.js    # Handles user authentication
│   │   └── mailController.js     # Handles email functionalities
│   ├── routes
│   │   ├── auth.js              # Routes for authentication
│   │   └── mail.js              # Routes for email functionalities
│   ├── services
│   │   └── mailer.js            # Mailer service for sending emails
│   └── views
│       ├── login.html           # Login page
│       ├── register.html        # Registration page
│       ├── compose.html         # Compose email page
│       └── inbox.html           # Inbox page
├── public
│   ├── css
│   │   └── styles.css           # CSS styles for the application
│   └── js
│       └── app.js               # Client-side JavaScript
├── .env                          # Environment variables
├── .gitignore                    # Git ignore file
├── package.json                  # npm configuration file
└── README.md                     # Project documentation
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd web-mail-app
   ```
3. Install the dependencies:
   ```
   npm install
   ```
4. Create a `.env` file in the root directory and add your environment variables.

## Usage
1. Start the server:
   ```
   node src/server.js
   ```
2. Open your browser and go to `http://localhost:3000` to access the application.

## Contributing
Feel free to submit issues or pull requests for improvements or bug fixes. 

## License
This project is licensed under the MIT License.