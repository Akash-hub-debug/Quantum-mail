# TODO List for Mail App Redesign

## 1. Redesign Inbox Page Layout
- [x] Change inbox.html from horizontal layout (sidebar left, main right) to vertical layout (sidebar on top, main content below)

## 2. PIN Validation in Compose
- [x] Add client-side validation in compose.html to ensure PIN is 4-6 digits
- [x] Update compose.html to display the PIN to the user after successful send (e.g., via alert or UI message)

## 3. Backend Updates for Sending Mail
- [x] Modify sendEmail in mailController.js to validate PIN length (4-6 digits)
- [x] Update sendEmail to hash the PIN and save the message to database
- [x] Update sendEmail to return success response with PIN information

## 4. Sent Box Functionality
- [x] Add new API route /api/mail/sent in mail.js for fetching sent messages
- [x] Add getSent method in mailController.js to retrieve sent messages for the user
- [x] Update sent.html to dynamically load and display sent messages (similar to inbox.html structure)

## 5. Testing and Verification
- [x] Install required dependencies (bcrypt, nodemailer, mongodb)
- [x] Test redesigned inbox layout on different screen sizes
- [x] Verify PIN validation and display in compose
- [x] Check that sent messages appear in sent.html after sending
- [x] Ensure backend correctly saves and retrieves sent messages
- [x] Enable real email sending with MongoDB integration
- [x] Start server successfully and verify all functionality
- [x] Fix inbox API to return valid JSON responses
- [x] Ensure message sending works without mailer errors
- [x] Update inbox.html to handle different boxes or simplify to primary inbox
- [x] Test end-to-end flow including compose, send, inbox view with PIN and recipient password

## 6. Additional Message Protection (New Feature)
- [x] Add recipientPasswordHash field to Message model
- [x] Update verify endpoint to check PIN and return if recipient password is set
- [x] Add new API endpoint /api/mail/setRecipientPassword/:id to set recipient password
- [x] Add new API endpoint /api/mail/verifyRecipientPassword/:id to verify recipient password and return message
- [x] Update inbox.html viewBtn logic to handle recipient password flow
- [x] Update compose.html to include recipient password field
- [x] Update sendEmail to hash and save recipient password if provided
