class Mailer {
    constructor(transporter) {
        this.transporter = transporter;
    }

    async sendEmail(to, subject, text) {
        const mailOptions = {
            from: process.env.EMAIL_FROM,
            to: to,
            subject: subject,
            text: text,
        };

        try {
            const info = await this.transporter.sendMail(mailOptions);
            return info;
        } catch (error) {
            throw new Error('Error sending email: ' + error.message);
        }
    }
}

module.exports = Mailer;