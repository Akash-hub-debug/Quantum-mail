const express = require('express');
const router = express.Router();
const MailController = require('../controllers/mailController');
const authMiddleware = require('./authMiddleware');

const mailController = new MailController();

// Route for composing an email
router.post('/compose', authMiddleware, mailController.composeEmail.bind(mailController));

// Route for sending an email
router.post('/send', authMiddleware, mailController.sendEmail.bind(mailController));

// Route for getting inbox messages
router.get('/inbox', authMiddleware, mailController.getInbox.bind(mailController));

// Route for getting sent messages
router.get('/sent', authMiddleware, mailController.getSent.bind(mailController));

// Route for verifying PIN
router.post('/verify/:id', authMiddleware, mailController.verifyPin.bind(mailController));

// Route for setting recipient password
router.post('/setRecipientPassword/:id', authMiddleware, mailController.setRecipientPassword.bind(mailController));

// Route for verifying recipient password
router.post('/verifyRecipientPassword/:id', authMiddleware, mailController.verifyRecipientPassword.bind(mailController));

module.exports = router;
