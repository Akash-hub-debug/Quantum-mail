// Temporarily bypassing DB for demo/testing purposes
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('./usermodel');

class AuthController {
    async registerUser(req, res) {
        try {
            const { username, email, password } = req.body;

            const existingUser = await User.findOne({ $or: [{ email }, { username }] });
            if (existingUser) {
                return res.status(400).json({ message: 'User already exists' });
            }
            const passwordHash = await bcrypt.hash(password, 10);
            const user = new User({ username, email, passwordHash });
            await user.save();
            res.status(201).json({ message: 'User registered successfully' });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    }

    async loginUser(req, res) {
        try {
            const { email, password } = req.body;
            
            const user = await User.findOne({ email });
            if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }
            
            const token = jwt.sign({ id: user._id, email: user.email, username: user.username }, process.env.JWT_SECRET || 'secret');
            res.status(200).json({ message: 'Login successful', token, user: { email: user.email, username: user.username } });
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    }
}

module.exports = AuthController;
