// Temporarily bypassing DB for demo/testing purposes
const bcrypt = require('bcrypt');
// const Message = require('./messagemodel');
// const User = require('./usermodel');
// const Mailer = require('../services/mailer');
// const nodemailer = require('nodemailer');

class MailController {
    constructor() {
        // Initialize mailer with nodemailer (optional)
        // if (process.env.SMTP_HOST) {
        //     this.transporter = nodemailer.createTransporter({
        //         host: process.env.SMTP_HOST,
        //         port: process.env.SMTP_PORT,
        //         secure: false, // true for 465, false for other ports
        //         auth: {
        //             user: process.env.SMTP_USER,
        //             pass: process.env.SMTP_PASS
        //         }
        //     });
        //     this.mailer = new Mailer(this.transporter);
        // }
    }

    async composeEmail(req, res) {
        // Logic for rendering the compose email view
        res.render('compose');
    }

    async sendEmail(req, res) {
        const { to, subject, body, pin, recipientPassword } = req.body;

        // Validate PIN length
        if (!pin || pin.length < 4 || pin.length > 6 || !/^\d+$/.test(pin)) {
            return res.status(400).json({ message: 'PIN must be 4-6 digits' });
        }

        try {
            // Get sender from JWT or session
            const senderEmail = req.user ? req.user.email : 'user@example.com'; // Assuming req.user is set by auth middleware

            // Hash the PIN
            const pinHash = await bcrypt.hash(pin, 10);

            // Hash recipient password if provided
            let recipientPasswordHash = null;
            if (recipientPassword) {
                recipientPasswordHash = await bcrypt.hash(recipientPassword, 10);
            }

            // Mock save message to database
            // const message = new Message({
            //     from: senderEmail,
            //     to,
            //     subject: subject || '',
            //     body,
            //     pinHash,
            //     recipientPasswordHash
            // });
            // await message.save();

            // Send email using mailer service (optional - comment out if not configured)
            // await this.mailer.sendEmail(to, subject || '(no subject)', body);

            res.status(200).json({ message: 'Email sent successfully!', pin: pin, hasRecipientPassword: !!recipientPassword });
        } catch (error) {
            res.status(500).json({ message: 'Failed to send email', error: error.message });
        }
    }

    async getInbox(req, res) {
        try {
            // Mock messages
            const messages = [
                { _id: 'mock1', from: 'test@example.com', subject: 'Test Message 1', body: 'This is a test message.', sentAt: new Date() },
                { _id: 'mock2', from: 'another@example.com', subject: 'Test Message 2', body: 'Another test message.', sentAt: new Date() }
            ];
            res.json({ messages });
        } catch (error) {
            res.status(500).json({ message: 'Failed to fetch inbox messages', error: error.message });
        }
    }

    async getSent(req, res) {
        try {
            // Mock sent messages
            const messages = [
                { _id: 'sent1', to: 'recipient@example.com', subject: 'Sent Test', body: 'Sent message body.', sentAt: new Date() }
            ];
            res.json({ messages });
        } catch (error) {
            res.status(500).json({ message: 'Failed to fetch sent messages', error: error.message });
        }
    }

    async verifyPin(req, res) {
        const { id } = req.params;
        const { pin } = req.body;

        try {
            // Mock message
            const message = { _id: id, pinHash: await bcrypt.hash('1234', 10), recipientPasswordHash: null, from: 'sender@example.com', subject: 'Mock Subject', body: 'Mock Body' };

            const isPinValid = await bcrypt.compare(pin, message.pinHash);
            if (!isPinValid) {
                return res.status(401).json({ error: 'Invalid PIN' });
            }

            // Check if recipient password is set
            if (message.recipientPasswordHash) {
                return res.json({ requiresRecipientPassword: true });
            } else {
                return res.json({
                    from: message.from,
                    subject: message.subject,
                    body: message.body
                });
            }
        } catch (error) {
            res.status(500).json({ error: 'Failed to verify PIN' });
        }
    }

    async setRecipientPassword(req, res) {
        const { id } = req.params;
        const { password } = req.body;

        try {
            // Mock set
            res.json({ message: 'Recipient password set successfully' });
        } catch (error) {
            res.status(500).json({ error: 'Failed to set recipient password' });
        }
    }

    async verifyRecipientPassword(req, res) {
        const { id } = req.params;
        const { password } = req.body;

        try {
            // Mock verify
            res.json({
                from: 'sender@example.com',
                subject: 'Mock Subject',
                body: 'Mock Body'
            });
        } catch (error) {
            res.status(500).json({ error: 'Failed to verify recipient password' });
        }
    }
}

module.exports = MailController;
