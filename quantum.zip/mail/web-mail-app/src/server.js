 require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const authRoutes = require('./routes/auth');
const mailRoutes = require('./routes/mail');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// api routes
app.use('/api/auth', authRoutes);
app.use('/api/mail', mailRoutes);

// serve public (css/js) and views (html)
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.use('/', express.static(path.join(__dirname, 'views')));

// start with db
const start = async () => {
  
  const mongoUrl = process.env.DATABASE_URL;
  if (!mongoUrl) {
    console.error('Please set DATABASE_URL in .env');
    process.exit(1);
  }
  await mongoose.connect(mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true });
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
};

start().catch(err => {
  console.error('Startup error', err);
  process.exit(1);
});
